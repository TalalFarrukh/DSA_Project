#ifndef ALLHEADERS_H_
#define ALLHEADERS_H_


#include "Aisle.h"
#include "Customer.h"
#include "BasketOfCustomer.h"
#include "Product.h"
#include "Cashier.h"
#include "Shop.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>

#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>


#endif