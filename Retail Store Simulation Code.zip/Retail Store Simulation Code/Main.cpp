#include "AllHeaders.h"
using namespace std;
using namespace sf;


//All extra related functions
void ExitButton(int x, int y, RenderWindow* M) {
    if (Mouse::isButtonPressed(Mouse::Button::Left) && x >= 1705 && x <= 1875 && y >= 65 && y <= 120)
        M->close();
}       //Function to exit the program 

void OpenClose(int x, int y, bool &status, Event *E, RenderWindow *M) {
    while (M->pollEvent(*E)) {
        if (E->type == E->MouseButtonPressed && x >= 1525 && x <= 1645 && y >= 40 && y <= 150 && !status) {
            if (E->mouseButton.button == Mouse::Left)
                status = true;
        }
        else if (E->type == E->MouseButtonPressed && x >= 1525 && x <= 1645 && y >= 40 && y <= 150 && status) {
            if (E->mouseButton.button == Mouse::Left)
                status = false;
        }
    }
}       //Function to Open or Close the shop

int main() {        //Main Window
    RenderWindow MW(VideoMode(1920, 1080), "Retail Store Simulation", Style::Close | Style::Titlebar);      //Declaring the window frame

    //Background music
    Music bgmusic; bgmusic.openFromFile("Music/BGMusic.ogg"); bgmusic.setVolume(10);

    //First frame textures and sprites
    Texture* _BG1 = new Texture; _BG1->loadFromFile("Images/Opening.png");
    Sprite* BG1 = new Sprite; BG1->setTexture(*_BG1);

    //Second frame textures, sprites, fonts and texts
    Texture* _BG2 = new Texture; _BG2->loadFromFile("Images/Background.png");
    Sprite* BG2 = new Sprite; BG2->setTexture(*_BG2);

    Texture* _Open = new Texture; Texture* _Close = new Texture;
    _Open->loadFromFile("Images/Open.png"); _Close->loadFromFile("Images/Close.png");
    Sprite* OpCl = new Sprite; OpCl->setPosition(405.f, 65.f);

    Font abc; abc.loadFromFile("Font/lonely/Lonely.ttf");
    Text PersonData, AisleData;
    PersonData.setFont(abc); PersonData.setFillColor(Color::Black); PersonData.setStyle(Text::Bold); PersonData.setCharacterSize(26); 
    PersonData.setString("\tPotato\t\t\tHHH\t\nTomato\nLomato\nHomato\n");
    AisleData.setFont(abc);

    bool f1 = true, f2 = false, isOpen = false;     //Conditions to be used later
    Shop shop;      //Declaring the Shop
    bgmusic.play();     //Play the music

    while (MW.isOpen())         //The while loop to keep the window open
    {
        int mp_x = Mouse::getPosition(MW).x; int mp_y = Mouse::getPosition(MW).y;       //Getting the mouse position every frame

        Event event;        //Event to be used for mouse button interactions
        while (MW.pollEvent(event))
        {
            if (event.type == Event::Closed)
                MW.close();
        }       //To close the program through 'X'

        if (f1 == true) {
            MW.clear(); MW.draw(*BG1); MW.display();
            //Exit Button
            if (Mouse::isButtonPressed(Mouse::Button::Left) && mp_x >= 865 && mp_x <= 1055 && mp_y >= 540 && mp_y <= 600)       //Exiting the program
                MW.close();

            if (Mouse::isButtonPressed(Mouse::Button::Left) && mp_x >= 850 && mp_x <= 1070 && mp_y >= 305 && mp_y <= 505) {     //Opening the shop in the 1st frame
                f2 = true; f1 = false; isOpen = true; delete _BG1; delete BG1;
            }
        }

        if (f2 == true) {       //2nd frame where the main show takes place
            MW.clear();     //Clearing all the drwaing from the previous frame

            //All the main logic below
            shop.SpawnCustomer(isOpen); shop.CustomerShop(); shop.CashOutCustomer();      
            
            if (isOpen)
                OpCl->setTexture(*_Open);
            else
                OpCl->setTexture(*_Close);

            MW.draw(*BG2); MW.draw(*OpCl); shop.drawCustomer(&MW); shop.Restock(&MW);       //Draw the sprites, textures, texts and fonts
            shop.DetectCustomer(&MW, mp_x, mp_y); shop.DetectAisle(&MW, mp_x, mp_y);
            MW.display();       //Displaying the drawings
            ExitButton(mp_x, mp_y, &MW); OpenClose(mp_x, mp_y, isOpen, &event, &MW);        //Functions to exit the program, open or close the shop anytime the user wants
        }
    }
}