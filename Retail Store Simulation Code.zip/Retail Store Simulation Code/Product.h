#ifndef PRODUCT_H_
#define PRODUCT_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


class Product {
	public:
		string TypeOfProduct;		//Product type
		int AisleNumber;		//Aisle number it is placed in

		Product(){}

		void addProduct(string TOP, int AN) {
			TypeOfProduct = TOP, AisleNumber = AN;
		}		//Adding product into an aisle

		~Product(){}
};


#endif