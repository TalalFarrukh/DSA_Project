#ifndef BASKETOFCUSTOMER_H_
#define BASKETOFCUSTOMER_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>

#include "Product.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


struct BOCStruct{		//Linked list of a customer basket
	Product Products;
	BOCStruct *next, *previous;
};

class BOC {
	private:
		BOCStruct *head, *BPointer, *LastP;		//Pointers for the linked list
	public:
		int Count, BasketLimit;		//Count - keep track of amount of products, BasketLimit - Basket limit

		BOC() {
			head = nullptr; Count = 0; BasketLimit = 10;
		}		//Initializing required variables

		void PutInBasket(Product P) {		//Function to put products in the basket linked list
			BOCStruct *fnode, *newnode;
			fnode = new BOCStruct, newnode = new BOCStruct;
			if (!head) {
				fnode->Products = P, fnode->next = nullptr, fnode->previous = nullptr;
				head = fnode; LastP = head; Count++;
			}
			else {
				newnode->Products = P, newnode->next = nullptr, newnode->previous = LastP;
				LastP->next = newnode; LastP = LastP->next;
				Count++;
			}
		}

		Product RemoveFromBasket() {		//Function to remove product from the basket linked list when cashing out, starts from the last product that was put in
			BOCStruct *Temp;
			Temp = LastP; LastP = LastP->previous; Count--;
			return Temp->Products;
		}
};


#endif 

