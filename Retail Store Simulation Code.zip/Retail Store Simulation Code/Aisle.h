#ifndef AISLE_H_
#define AISLE_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>

#include "Product.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


struct AisleStack {		//Stack of items in an aisle
	Product SOfP[10];
	int T;
};

class Aisle {
	private:
		bool KR1, KR2, GoBack;		//Conditions to be used in restocking function
		float PosX, PosY;		//Position X and Y of staff
		Clock Aclock;
		int h;

	public:
		AisleStack Stack1, Stack2;		//Every aisle is divided into two stacks
		Sprite Staff; Texture _Staff;	

		Aisle(string TOP1, string TOP2, int AN1, int AN2){	
			KR1 = KR2 = GoBack = false; h = 0;
			PosX = 835; PosY = 940;
			_Staff.loadFromFile("Images/Staff.png"); Staff.setPosition(PosX, PosY); Staff.setTexture(_Staff);
			Stack1.T = Stack2.T = -1;
			for (int i = 0; i < 10; i++) {
				Stack1.T++;
				Stack1.SOfP[Stack1.T].addProduct(TOP1, AN1);
			}
			for (int i = 0; i < 10; i++) {
				Stack2.T++;
				Stack2.SOfP[Stack2.T].addProduct(TOP2, AN2);
			}
		}		//Initializing the required variables plus filling all the aisles with items

		void RestockStack(float X1, float X2, float Y1, string TOP1, string TOP2, int AN1, int AN2, RenderWindow *M) {	//Checking and restocking aisles
			float y; y = Aclock.getElapsedTime().asSeconds();
			if (Stack1.T < 4 || KR1) {		//Check the 1st stack of an aisle and refill it
				if (PosY >= Y1 && !KR1) {
					PosY -= 0.6; Staff.setPosition(PosX, PosY);
				}		//Staff walks Y first
				else if (PosX <= X1 && !KR1) {
					PosX += 0.6; Staff.setPosition(PosX, PosY);
				}		//Then staff walks X
				else {		//Once in position, it starts restocking
					KR1 = true;
					if (h == 0) {
						Aclock.restart(); h = 1;
					}
					else if (y >= 2 && !GoBack) {
						Stack1.T++; Stack1.SOfP[Stack1.T].addProduct(TOP1, AN1);
						if (Stack1.T == 9)
							GoBack = true;
						h = 0;
					}		//2 seconds per product to restock
					if (GoBack) {	//Once done restocking
						if (PosX >= 835) {
							PosX -= 0.6; Staff.setPosition(PosX, PosY);
						}	//Move back X
						else if (PosY <= 940) {
							PosY += 0.6; Staff.setPosition(PosX, PosY);
						}	//Then move back Y
						else
							KR1 = GoBack = false;
					}
				}
				M->draw(Staff);		//Draw the staff member in the window
			}
			else if (Stack2.T < 4 || KR2) {		//Else if stack 2 is low, the rest is the same
				if (PosY >= Y1 && !KR2) {
					PosY -= 0.6; Staff.setPosition(PosX, PosY);
				}
				else if (PosX <= X2 && !KR2) {
					PosX += 0.6; Staff.setPosition(PosX, PosY);
				}
				else {
					KR2 = true;
					if (h == 0) {
						Aclock.restart(); h = 1;
					}
					else if (y >= 2 && !GoBack) {
						Stack2.T++; Stack2.SOfP[Stack2.T].addProduct(TOP2, AN2);
						if (Stack2.T == 9)
							GoBack = true;
						h = 0;
					}
					if (GoBack) {
						if (PosX >= 835) {
							PosX -= 0.6; Staff.setPosition(PosX, PosY);
						}
						else if (PosY <= 940) {
							PosY += 0.6; Staff.setPosition(PosX, PosY);
						}
						else
							KR2 = GoBack = false;
					}
				}
				M->draw(Staff);
			}
		}

		Product RemoveFromStack(int i) {		//When the customer comes to shop, this is the function used for removing products from the stack
			if (Stack1.SOfP[Stack1.T].AisleNumber == i) {
				Stack1.T--; return Stack1.SOfP[Stack1.T + 1];
			}
			else if (Stack2.SOfP[Stack2.T].AisleNumber == i) {
				Stack2.T--; return Stack2.SOfP[Stack2.T + 1];
			}
		}
};


#endif