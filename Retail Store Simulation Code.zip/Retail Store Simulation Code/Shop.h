#ifndef SHOP_H_
#define SHOP_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>

#include "Customer.h"
#include "BasketOfCustomer.h"
#include "Cashier.h"
#include "Aisle.h"
#include "Product.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


struct ShopStruct {
	Customer customer;
	ShopStruct *next, *previous;
};		//A linked list of customers

class Shop {		//Class for customers, aisles and cashiers
	private:
		ShopStruct *head, *SPointer;		//Customer head and traverse pointers
		int ShopLimit;
		float SpawnTime, CPosX, CPosY;		//CPosX and CPosY are customer positions
		Clock clock;						//To be used to monitor time and execute functions according to that
		string _A, _B, _C, _D, _E, _F;		//Used to store the items the customer has in his basket
	public:
		int Count, g = 0;					//Count - count customers in a shop, g - used to help keep track of time for spawning of customers
		Aisle aisle1, aisle2, aisle3;		//The 3 aisles
		Cashier cashier1, cashier2, cashier3;	//The 3 cashiers
		RectangleShape MsgBox, AMsgBox; Text PersonData, AData; Font abc;		//Used for displaying items in a customer's basket or the aisle

		Shop() : aisle1("A", "B", 1, 2), aisle2("C", "D", 3, 4), aisle3("E", "F", 5, 6) {
			head = nullptr;	Count = SpawnTime = 0;  ShopLimit = 20; srand(time(0));

			abc.loadFromFile("Font/lonely/Lonely.ttf"); PersonData.setFont(abc); AData.setFont(abc);
			
			PersonData.setFillColor(Color::Black); PersonData.setStyle(Text::Bold); PersonData.setCharacterSize(22);
			AData.setFillColor(Color::Black); AData.setStyle(Text::Bold); AData.setCharacterSize(22);
			
			MsgBox.setFillColor(Color::Cyan); MsgBox.setOutlineColor(Color::Black); MsgBox.setOutlineThickness(4);
			AMsgBox.setFillColor(Color::Cyan); AMsgBox.setOutlineColor(Color::Black); AMsgBox.setOutlineThickness(4);
		}	//Initializing text and other objects

		void CreateCustomer() {
			if (!head) {
				head = new ShopStruct;
				head->previous = head->next = nullptr; Count++;
			}
			else {
				ShopStruct* NShop = new ShopStruct; NShop->next = nullptr;
				SPointer = head;
				while (SPointer->next)
					SPointer = SPointer->next;
				NShop->previous = SPointer; SPointer->next = NShop;
				Count++;
			}
		}		//Function to create customers in the linked list of the shop

		void SpawnCustomer(bool isOpen) {
			float y;
			y = clock.getElapsedTime().asSeconds();
			if (g == 0 || !isOpen) {
				SpawnTime = rand() % 16 + 7; //change to 16 and 7
				clock.restart(); g = 1;
			}
			else if (Count <= ShopLimit && isOpen && y >= SpawnTime) {
				this->CreateCustomer();	g = 0;
			}
		}	//Function to spawn the customers inside the shop

		void CustomerShop() {
			SPointer = head;
			while (SPointer) {
				SPointer->customer.WalkShop(&aisle1, &aisle2, &aisle3, &cashier1, &cashier2, &cashier3);
				SPointer = SPointer->next;
			}
		}		//Function to make the customer do the shopping

		void drawCustomer(RenderWindow *M) {
			SPointer = head;
			while (SPointer) {
				SPointer->customer.customer.setTexture(SPointer->customer._customer);
				M->draw(SPointer->customer.customer);
				SPointer = SPointer->next;
			}
		}		//Drawing the customer in the main window

		void Restock(RenderWindow *M) {
			aisle1.RestockStack(1285, 1530, 230, "A", "B", 1, 2, M);
			aisle2.RestockStack(1285, 1530, 495, "C", "D", 3, 4, M);
			aisle3.RestockStack(1285, 1530, 785, "E", "F", 5, 6, M);
		}		//Restock the items on the aisle

		void CashOutCustomer() {
			SPointer = head;
			while (SPointer) {
				SPointer->customer.CashOut(&cashier1, &cashier2, &cashier3);
				if (SPointer->customer.DeleteTime) {
					this->DeleteCustomer(SPointer); Count--;
				}
				SPointer = SPointer->next;
			}
		}		//Function to make the customer cashout when done shopping

		void DeleteCustomer(ShopStruct *S) {
			ShopStruct *TempNext, *TempPrev, *TempDelete;
			TempDelete = S;
			if (S == head) {
				if (!S->next) {
					head = nullptr;
				}
				else {
					TempNext = S->next; head = TempNext; S = head; head->previous = nullptr;
				}
				TempDelete = nullptr; delete TempDelete;
			}
			else if(!S->next) {
				S = S->previous; S->next = nullptr; TempDelete = nullptr; delete TempDelete;
			}
			else {
				TempNext = S->next; TempPrev = S->previous;
				TempNext->previous = TempPrev; TempPrev->next = TempNext; S = TempPrev; 
				TempDelete = nullptr; delete TempDelete;
			}
		}		//Delete customer once its done cashing out

		void DetectCustomer(RenderWindow *M, float MPosX, float MPosY) {
			SPointer = head;
			while (SPointer) {
				_A = "\n\tA\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[0]); _B = "\n\tB\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[1]);
				_C = "\n\tC\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[2]); _D = "\n\tD\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[3]);
				_E = "\n\tE\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[4]); _F = "\n\tF\t\t\t\t\t\t" + to_string(SPointer->customer.CAP[5]);
				CPosX = SPointer->customer.customer.getPosition().x, CPosY = SPointer->customer.customer.getPosition().y;
				if (MPosX >= CPosX + 60 && MPosX <= CPosX + 115 && MPosY >= CPosY + 30 && MPosY <= CPosY + 75) {
					PersonData.setPosition(MPosX - 30, MPosY + 30); MsgBox.setPosition(PersonData.getPosition().x, PersonData.getPosition().y);
					MsgBox.setSize(Vector2f(PersonData.getLocalBounds().width + 10, PersonData.getLocalBounds().height + 10));
					PersonData.setString(" Product Type\tQuantity " + _A + _B + _C + _D + _E + _F);
					M->draw(MsgBox); M->draw(PersonData);
				}
				SPointer = SPointer->next;
			}
		}		//Display the type and amount of products the customer has

		void DetectAisle(RenderWindow* M, float MPosX, float MPosY) {
			AData.setPosition(MPosX - 30, MPosY + 30); AMsgBox.setPosition(AData.getPosition().x, AData.getPosition().y);
			AMsgBox.setSize(Vector2f(AData.getLocalBounds().width + 10, AData.getLocalBounds().height + 10));
			if (MPosX >= 1225 && MPosX <= 1485 && MPosY >= 350 && MPosY <= 455) {
				AData.setString(" Product Type: " + aisle1.Stack1.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle1.Stack1.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
			if (MPosX >= 1495 && MPosX <= 1755 && MPosY >= 350 && MPosY <= 455) {
				AData.setString(" Product Type: " + aisle1.Stack2.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle1.Stack2.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
			if (MPosX >= 1225 && MPosX <= 1485 && MPosY >= 630 && MPosY <= 735) {
				AData.setString(" Product Type: " + aisle2.Stack1.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle2.Stack1.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
			if (MPosX >= 1495 && MPosX <= 1755 && MPosY >= 630 && MPosY <= 735) {
				AData.setString(" Product Type: " + aisle2.Stack2.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle2.Stack2.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
			if (MPosX >= 1225 && MPosX <= 1485 && MPosY >= 905 && MPosY <= 1010) {
				AData.setString(" Product Type: " + aisle3.Stack1.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle3.Stack1.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
			if (MPosX >= 1495 && MPosX <= 1755 && MPosY >= 905 && MPosY <= 1010) {
				AData.setString(" Product Type: " + aisle3.Stack2.SOfP[0].TypeOfProduct + "\n\n Quantity: " + to_string(aisle3.Stack2.T + 1));
				M->draw(AMsgBox); M->draw(AData);
			}
		}		//Display the items in an aisle
};


#endif
