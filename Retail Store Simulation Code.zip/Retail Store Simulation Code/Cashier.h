#ifndef CASHIER_H_
#define CASHIER_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>

#include "Product.h"
#include "BasketOfCustomer.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


class Cashier {		
	private:
		int LSLimit;		//Line limit
		Product* CProduct;	//The product to scan

	public:
		int LineSize;		//Current line size
		bool W1, W2, W3, W4;	//Variables to make sure the line positions are occupied or no

		Cashier() {		
			LineSize = 0; LSLimit = 4;
			W1 = W2 = W3 = W4 = false;
		}		//Initializing the required variables
};


#endif