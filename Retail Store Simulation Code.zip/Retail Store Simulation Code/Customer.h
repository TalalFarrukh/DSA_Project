#ifndef CUSTOMER_H_
#define CUSTOMER_H_
#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>
#include <ctime>

#include "BasketOfCustomer.h"
#include "Product.h"
#include "Aisle.h"
#include "Cashier.h"

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
using namespace std;
using namespace sf;


class Customer {
	private:
		int CAisle, CAProduct, ShopAgain, i, p, toBuy;		//i and p - to be used for tracking time once again, CAisle, CAProduct - Aisle and amount of products to shop respectively
		int w1, w2, w3, w4;		//Varaibles to make customer wait in line
		float PosX, PosY;		//PosX and PosY - position of customer sprite x and y, Stime1 and Stime2 - 
		bool isShopping, isCashing, firstMove, MovetoPos, ShoppingDone;		//Variables for smooth shopping and cashing out for customer
		bool Line1, Line2, Line3;		//To check if either of the 3 cashiers are occupied 
		Clock Sclock, Pclock;			//Used for shopping and cashing out
		string CheckProducts[6] = { "A", "B", "C", "D", "E", "F" };		//Used to store the items in a customer's basket
	public:
		BOC Basket;	Sprite customer; Texture _customer; bool DeleteTime; int CAP[6] = { 0,0,0,0,0,0 };	//CAP - Used to keep track of amount of each item the customer has, DeleteTime - Used when its time to destroy the customer
		
		Customer(){
			isShopping = true; isCashing = firstMove = MovetoPos = ShoppingDone = DeleteTime = false;
			Line1 = Line2 = Line3 = false;
			w1 = w2 = w3 = w4 = i = p = toBuy = 0;
			PosX = 130; PosY = 230;
			_customer.loadFromFile("Images/Customer.png");
			customer.setPosition(PosX, PosY);
			CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;	//randomly generate the Aisle customer has to go to, the amount of products he has to buy and whether he will shop again or no
		}	//Used to initialize the needed variables and objects

		void WalkShop(Aisle *A1, Aisle *A2, Aisle *A3, Cashier *C1, Cashier *C2, Cashier *C3) {		//Used for walking the customer to shop for items and back
			if (!firstMove) {		//The first compulsory steps every customer has to take to reach a key point for any further steps
				PosX += 0.6;	customer.setPosition(PosX, PosY);
				if (PosX >= 880)
					firstMove = true;
			}
			else {		//Once the above if statement is false, the following executes
				if (!isShopping)	//If the customer is done shopping then return
					return;
				if (CAisle == 1) {		//If the selected Aisle is this one, else move to the next if statement
					if (PosX <= 1285 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}		//First move to this X Position
					else {	//Once done moving to this X Position then do the following
						MovetoPos = true;		//Makes sure the else parts keeps running
						ShoppingDone = this->doShopping(A1, CAisle);		//Executes the shopping function until the customer is done shopping from this aisle
						if (ShoppingDone) {		//Once customer is done shopping
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}		//Moving back to that key point
							else {		//Once moved back execute the following
								if (ShopAgain == 0) {		//If customer doesn't want to shop again then make isShopping false so it doesn't shop again and go for cashing out
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {		//Else generate all those random variables again and run this whole function again
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}		
				else if (CAisle == 2) {
					if (PosX <= 1530 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}
					else {
						MovetoPos = true;
						ShoppingDone = this->doShopping(A1, CAisle);
						if (ShoppingDone) {
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								if (ShopAgain == 0) {
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}
				else if (CAisle == 3) {		//The rest of the else if conditions are exactly the same with one difference mentioned below here:
					if (PosY <= 495 && !MovetoPos) {
						PosY += 0.6; customer.setPosition(PosX, PosY);
					}	//First move to Y position
					else if (PosX <= 1285 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}	//Then move to X position
					else {
						MovetoPos = true;
						ShoppingDone = this->doShopping(A2, CAisle);
						if (ShoppingDone) {
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							} //Go back to this X position
							else if (PosY >= 230) {
								PosY -= 0.6; customer.setPosition(PosX, PosY);
							}	//Then go back to this Y position
							else {
								if (ShopAgain == 0) {
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}
				else if (CAisle == 4) {
					if (PosY <= 495 && !MovetoPos) {
						PosY += 0.6; customer.setPosition(PosX, PosY);
					}
					else if (PosX <= 1530 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}
					else {
						MovetoPos = true;
						ShoppingDone = this->doShopping(A2, CAisle);
						if (ShoppingDone) {
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else if (PosY >= 230) {
								PosY -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								if (ShopAgain == 0) {
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}
				else if (CAisle == 5) {
					if (PosY <= 785 && !MovetoPos){
						PosY += 0.6; customer.setPosition(PosX, PosY);
					}
					else if (PosX <= 1285 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}
					else {
						MovetoPos = true;
						ShoppingDone = this->doShopping(A3, CAisle);
						if (ShoppingDone) {
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else if (PosY >= 230) {
								PosY -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								if (ShopAgain == 0) {
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}
				else if (CAisle == 6) {
					if (PosY <= 785 && !MovetoPos){
						PosY += 0.6; customer.setPosition(PosX, PosY);
					}
					else if (PosX <= 1530 && !MovetoPos) {
						PosX += 0.6; customer.setPosition(PosX, PosY);
					}
					else {
						MovetoPos = true;
						ShoppingDone = this->doShopping(A3, CAisle);
						if (ShoppingDone) {
							if (PosX >= 880) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else if (PosY >= 230) {
								PosY -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								if (ShopAgain == 0) {
									isShopping = false; isCashing = true; this->CheckLine(C1, C2, C3);
								}
								else {
									CAisle = rand() % 6 + 1; CAProduct = rand() % 3 + 1; ShopAgain = rand() % 2;
									MovetoPos = false; toBuy = 0;
								}
							}
						}
					}
				}
			}
		}

		bool doShopping(Aisle *A, int u) {		//Once the customer is in position, he starts shopping using this function
			float y; y = Sclock.getElapsedTime().asSeconds(); Product X;	//X - to store the product temporarily, y - to store the time
			if (Basket.Count == Basket.BasketLimit || toBuy == CAProduct) {		//Making sure the basket isn't full OR the customer isn't done shopping
				if (Basket.Count == Basket.BasketLimit)
					ShopAgain = 0;
				return true;		//Will return true once customer is done shopping
			}
			else if (i == 0) {		//If i=0, the clock will restart and this else if condition won't run because i=1 now, when i=0 again, this condition runs again
				Sclock.restart(); i = 1;
				return false;
			}
			else {		//After the above condition becomes false, this executes
				if (y >= 4 && (A->Stack1.T > 0 || A->Stack2.T > 0)) {	//If time (y) is greater than 4 and the product is available then remove from the aisle and put into basket
					X = A->RemoveFromStack(u);
					Basket.PutInBasket(X);
					toBuy++; i = 0; this->CheckBasket(X.TypeOfProduct, 1);
				}
				return false;	//Keeps returning false because the customer isn't done shopping
			}
		}

		void CheckBasket(string A, int j) {		//Keeps track of each type of item that the customer has in basket, counts 0 products as well
			if (A == "A") {
				CAP[0] += j;
			}
			else if (A == "B") {
				CAP[1] += j;
			}
			else if (A == "C") {
				CAP[2] += j;
			}
			else if (A == "D") {
				CAP[3] += j;
			}
			else if (A == "E") {
				CAP[4] += j;
			}
			else if (A == "F") {
				CAP[5] += j;
			}
		}

		void CashOut(Cashier *C1, Cashier *C2, Cashier *C3) {			//Function for when the customer is ready to cashout
			float y; y = Pclock.getElapsedTime().asSeconds(); Product X;	//Same purpose as the one in the doShopping function
			if (Line1) {		//If Line1 is the suitable way to go
				if (PosY <= 355) {
					PosY += 0.6; customer.setPosition(PosX, PosY);
				}	//Move Y
				else {		//Once done Moving Y, check which position the customer has to wait in
					if (!C1->W1 || w1 == 1) {		//if 1st position is free
						if (PosX >= 255) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						} //Move to 1st Position
						else {	//Then start cashing out, 2 seconds per product
							C1->W1 = true; w1 = 1; w2 = 0; C1->W2 = false;
							if (p == 0) {
								Pclock.restart(); p = 1;
							}
							else if (Basket.Count != 0) {
								if (y >= 2) {
									X = Basket.RemoveFromBasket(); this->CheckBasket(X.TypeOfProduct, -1); p = 0;
								}
							}
							else {		//Once done shopping, move a bit more forward and then enable DeleteTime=true
								if (PosX >= 40) {
									PosX -= 0.6; customer.setPosition(PosX, PosY);
								}
								else {
									C1->W1 = false; C1->LineSize--; DeleteTime = true;
								}
							}
						}
					}
					else if (!C1->W2 || w2 == 1) {	//else if 2nd position is free and same for the other conditions
						if (PosX >= 315) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C1->W2 = true; w2 = 1; w3 = 0; C1->W3 = false;
						}
					}
					else if (!C1->W3 || w3 == 1) {
						if (PosX >= 375) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C1->W3 = true; w3 = 1; w4 = 0; C1->W4 = false;
						}
					}
					else if (!C1->W4 || w4 == 1) {
						if (PosX >= 435) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C1->W4 = true; w4 = 1;
						}
					}
				}
			}
			else if (Line2) {		//If Line2 is the suitable line, rest of the whole function is the same as Line1
				if (PosY <= 580) {
					PosY += 0.6; customer.setPosition(PosX, PosY);
				}
				else {
					if (!C2->W1 || w1 == 1) {
						if (PosX >= 255) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							if (PosX >= 255) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								C2->W1 = true; w1 = 1; w2 = 0; C2->W2 = false;
								if (p == 0) {
									Pclock.restart(); p = 1;
								}
								else if (Basket.Count != 0) {
									if (y >= 2) {
										X = Basket.RemoveFromBasket(); this->CheckBasket(X.TypeOfProduct, -1); p = 0;
									}
								}
								else {
									if (PosX >= 40) {
										PosX -= 0.6; customer.setPosition(PosX, PosY);
									}
									else {
										C2->W1 = false; C2->LineSize--; DeleteTime = true;
									}
								}

							}
						}
					}
					else if (!C2->W2 || w2 == 1) {
						if (PosX >= 315) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C2->W2 = true; w2 = 1; w3 = 0; C2->W3 = false;
						}
					}
					else if (!C2->W3 || w3 == 1) {
						if (PosX >= 375) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C2->W3 = true; w3 = 1; w4 = 0; C2->W4 = false;
						}
					}
					else if (!C2->W4 || w4 == 1) {
						if (PosX >= 435) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C2->W4 = true; w4 = 1;
						}
					}
				}
			}
			else if (Line3) {		//Same as Line2 and Line1
				if (PosY <= 805) {
					PosY += 0.6; customer.setPosition(PosX, PosY);
				}
				else {
					if (!C3->W1 || w1 == 1) {
						if (PosX >= 255) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							if (PosX >= 255) {
								PosX -= 0.6; customer.setPosition(PosX, PosY);
							}
							else {
								C3->W1 = true; w1 = 1; w2 = 0; C3->W2 = false;
								if (p == 0) {
									Pclock.restart(); p = 1;
								}
								else if (Basket.Count != 0) {
									if (y >= 2) {
										X = Basket.RemoveFromBasket(); this->CheckBasket(X.TypeOfProduct, -1); p = 0;
									}
								}
								else {
									if (PosX >= 40) {
										PosX -= 0.6; customer.setPosition(PosX, PosY);
									}
									else {
										C3->W1 = false; C3->LineSize--; DeleteTime = true;
									}
								}

							}
						}
					}
					else if (!C3->W2 || w2 == 1) {
						if (PosX >= 315) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C3->W2 = true; w2 = 1; w3 = 0; C3->W3 = false;
						}
					}
					else if (!C3->W3 || w3 == 1) {
						if (PosX >= 375) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C3->W3 = true; w3 = 1; w4 = 0; C3->W4 = false;
						}
					}
					else if (!C3->W4 || w4 == 1) {
						if (PosX >= 435) {
							PosX -= 0.6; customer.setPosition(PosX, PosY);
						}
						else {
							C3->W4 = true; w4 = 1;
						}
					}
				}
			}
		}

		void CheckLine(Cashier *C1, Cashier *C2, Cashier *C3) {		//Once customer is done shopping and isCashing=true, the customer immediately checks which line/cashier is the smallest 
			if (C1->LineSize <= C2->LineSize && C1->LineSize <= C3->LineSize && C1->LineSize != 4 && isCashing) {	//and pre-determines its path according before walking over
				Line1 = true; C1->LineSize++; 
			} //If he chooses this, the size of Line1 increases 
			else if (C2->LineSize <= C3->LineSize && C2->LineSize != 4 && isCashing) {
				Line2 = true; C2->LineSize++; 
			}	//else Line2
			else if (C3->LineSize != 4 && isCashing) {
				Line3 = true; C3->LineSize++; 
			}	//else Line3
		}

		~Customer(){}		//Customer destructor
};


#endif